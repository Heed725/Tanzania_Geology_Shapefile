# Tanzania Geology — QGIS project

## Open the map

1. Extract the complete ZIP into a normal folder on your computer.
2. Open **Tanzania_Geology_Styled.qgz** in QGIS. QGIS 3.34 or later is recommended, including QGIS 3.40.
3. Keep the `data` folder beside the project. All layers are included locally; no internet connection or plugin is required.
4. For the finished map, open **Project → Layouts → Tanzania Geology — A3 portrait**.
5. In the layout, use **Layout → Export as Image** or **Export as PDF**. Use 300 dpi for printing.

The supplied PNG shows the finished layout. The live canvas may show different label positions as its window size changes.

## Included layers

| Layer | Content |
| --- | --- |
| Geological units | All 623 source polygons, with original geology attributes |
| Active fault traces — GEM | 202 published traces in the regional map extent; Tanzania and border traces are darker |
| Tectonic belt labels | Six editable label anchors, including Tanzania Craton, Mozambique, Karagwe–Ankolean, Ubendian, Usagaran and Karoo |
| Cities and towns | 18 cartographic reference points |
| Country and water labels | Neighbouring countries, major lakes, ocean and islands |
| Lakes | 16 regional water polygons |
| Major rivers | Seven regional river features |
| Country boundaries | Ten countries intersecting the map frame |
| 2° geographic grid | A geographic coordinate grid for the map canvas |

The print layout has its own annotated grid. It omits the canvas grid to avoid drawing each grid line twice.

## Colours and labels

The colours are adapted from the supplied reference and the repository's existing project. They represent the actual source classification in `addtnl_inf`, with 17 legend entries including water and two polygons whose classification is blank. Adjacent young sediment classes intentionally share a pale yellow colour.

The source classification is broader than some units in the reference image. Subdivisions that are absent from the source data were not invented. Geological polygon outlines are **contacts**; the separate GEM line layer contains **active fault traces**.

Large belt labels are schematic cartographic labels; their point anchors do not delineate belt boundaries. Town coordinates are approximate reference locations. The fault dataset is independent of the geological polygons and is not a comprehensive inventory of every ancient fault or tectonic boundary in Tanzania.

Geological unit abbreviations from `abbr` appear when zooming closer than approximately **1:2,500,000**. The large belt labels remain visible at the national overview.

## Edit the map

- **Change colours:** right-click Geological units → Properties → Symbology. Edit a category's fill or contact outline.
- **Change fault appearance:** right-click Active fault traces — GEM → Properties → Symbology. The two rules distinguish Tanzania/border traces from regional context. They describe location, not fault certainty or fault type.
- **Move or rotate belt labels:** edit the Tectonic belt labels point layer. Move its point, or change `label`, `rotation` and `size` in the attribute table. `rotation` is in degrees; `size` is in points.
- **Hide a feature group:** uncheck its layer or group in the Layers panel.
- **Adjust code visibility:** Geological units → Properties → Labels → Rendering → Scale visibility.
- **Change the printed legend:** its rows are editable layout text and swatches. If you change map colours or category wording, update the corresponding print legend rows too. The Layers panel's categorized legend is linked to the layer renderer.
- **Reuse styles:** each layer has a `.qml` file in `styles`. The styles are also stored in the GeoPackage.

`Geological_units_legend.csv` lists exact source classifications, readable legend labels, hexadecimal colours and polygon counts.

## Data sources and attribution

**Geology:** Heed725, Tanzania_Geology_Shapefile, source commit `2c3db2bff74dbcf0fcedc4685eaacb5d1a910551`.
https://github.com/Heed725/Tanzania_Geology_Shapefile

Original geometry and fields are retained; the shapefile was converted to GeoPackage and given new styles and labelling. The repository describes educational/research use and requests citation of original geological survey sources. It does not supply a standard open-data licence for the geology layer; that original status remains unchanged.

**Faults:** GEM Foundation, GEM Global Active Faults Database, master commit `56816508ad92fd6846dad1163b1c8c01376a2cd1`.
https://github.com/GEMScienceTools/gem-global-active-faults

Styron, R. and Pagani, M. (2020), The GEM Global Active Faults Database, *Earthquake Spectra*, 36(1_suppl), 160–180. https://doi.org/10.1177/8755293020944182

East African traces in the included subset use the `Macgregor_AfricaFaults` catalog. Macgregor, D. (2015), History of the development of the East African Rift System: A series of interpreted maps through time, *Journal of African Earth Sciences*, 101, 232–252. https://doi.org/10.1016/j.jafrearsci.2014.09.016

The fault layer was selected and clipped to the map frame (28–41.5° E, 12.5° S–0.5° N) and converted to GeoPackage. Original catalog identifiers and the available name/slip-type fields are retained; missing source attributes remain blank. Fault data and adaptations of that layer are **CC BY-SA 4.0**. See `GEM_LICENSE.txt` and https://creativecommons.org/licenses/by-sa/4.0/. Supplied as-is, without warranties; no endorsement is implied.

**Country boundaries, lakes and rivers:** Natural Earth, 1:10 million vector data; public domain.
https://www.naturalearthdata.com/
https://github.com/nvkelso/natural-earth-vector

Regional features were clipped to the map frame; major rivers were selected using source `scalerank ≤ 6`. Natural Earth describes boundary and coastline features at its own cartographic resolution, which may differ slightly from geology boundaries. Source metadata and file hashes are in `data/source_manifest.json`.

**Project styling, label anchors and layout:** prepared for Hemed, October 2026. New cartographic styling and layout are made available under CC BY-SA 4.0; the source geology's separate status remains unchanged.

## Verification

The project was generated and rendered with QGIS 3.34.4, using WGS 84 (EPSG:4326), then reopened from a different folder to verify relative paths, layer counts, styling and the print layout. The printed preview was visually checked. No external tiles or temporary layers are required.

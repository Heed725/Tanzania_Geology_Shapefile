# Tanzania geology — dissolved reference map

## Open and print

1. Extract the entire ZIP into a folder.
2. Open **Tanzania_Geology_Reference.qgz** in QGIS 3.34 or later, including QGIS 3.40.
3. Keep the `data` folder beside the project. All data is local and works offline.
4. Open **Project → Layouts → Dissolved geology — uploaded map style** for the main print layout.
5. Open **Dissolved geology — with active faults** for a second print layout with GEM active-fault traces.
6. Export the selected layout as PNG or PDF using QGIS's layout export commands.

The main map uses the extent, compact layout, degree grid, pastel geological colours and rotated geological labels of the uploaded reference. The PNG is its preview.

## What changed

- The 623 source polygons are classified into 17 geological map units plus water, then **dissolved by map unit** into 18 multipart features.
- Adjacent polygons belonging to the same class share one geometry, removing their internal borders.
- Colours were sampled directly from the uploaded legend, including pale yellow Cenozoic sediments, coral Malagarasi sediments, red granulites, orange overprinted basement, violet Usagaran rocks and lavender Ubendian rocks.
- The southern overprint class has the reference's dark dot pattern.
- The source's mixed sediment classes are combined into one Cenozoic basin/coastal map unit.
- Geological belt labels were repositioned and rotated, including Malagarasi Supergroup and Marine Coastal Basin.
- Regional rivers were added at Natural Earth's scale ranks 1–9. Major river names use curved blue labels.
- Shared boundaries between selected basement units form the darker **Major basement contacts** layer.
- The published GEM active faults remain a separate optional overlay and have their own print layout.
- The original uploaded image is included as a georeferenced comparison layer.

## Accuracy and interpretation

**Geometry follows the supplied repository's shapefile.** The dissolve keeps the coverage of that GIS dataset. One invalid polygon, source UUID `471`, was repaired before union. Dissolve area differences are at numerical precision, below `4 × 10^-13` square degrees per map unit.

**The reference and the source GIS are different geological generalisations.** Some source attributes combine units that the uploaded map separates. In particular, Bukoba/Karagwe–Ankolean and granulite/overprint subdivisions cannot all be reconstructed exactly from the source attributes. Their reference-led regional interpretation is recorded separately in `ref_key` and `class_method`; the original age, lithology and tectonic-unit attributes remain available.

The resulting map is a closer visual match using the real source geometries, rather than a complete digitisation of every boundary in the screenshot. Treat `ref_key` as a cartographic interpretation of the supplied reference, not as a newly surveyed geological classification. The CSV crosswalk exposes the mapping of every source polygon.

The darker basement contacts are calculated from shared source boundaries. They represent **contacts**, with their source geometry retained. The independent GEM layer represents **active faults**. The reference's schematic black lines are not all identified faults in the supplied source data.

The reference raster is approximately registered to its printed 2° grid, using `longitude = 28 + (pixel_x − 46)/41` and `latitude = (5 − pixel_y)/41`. It is useful for visual comparison at national scale. The source GIS and the old reference have cartographic differences and local offsets.

## Inspect the layers

The optional group contains:

| Layer | Use |
| --- | --- |
| Original detailed geology — 623 polygons | Inspect the unchanged original geology attributes and source boundaries |
| Reference-classified source polygons | Inspect the per-polygon reference classification before dissolution |
| Active faults — GEM | Toggle the independent published fault dataset in the canvas |
| Uploaded reference — georeferenced | Compare with the actual supplied image |

To see the reference image, turn off the Labels, Dissolved geology and Water groups, then turn on the Uploaded reference layer. To compare interactively, set the raster opacity below 100% in its layer properties and toggle the geology groups.

## Edit the map

- **Colours and patterns:** Geological units → Properties → Symbology. The main layer is named **Geology — dissolved reference units** and is categorized using `ref_key`.
- **Individual original polygons:** use the optional classified source layer, then inspect `uuid`, `symbol_nr`, `tect_unit`, `ref_key` and `class_method`.
- **Large labels:** edit the Tectonic belt labels point layer. Move its point or change `label`, `rotation`, and `size`.
- **Rivers:** Properties → Labels controls curved names. Symbology controls their blue lines.
- **Print legend:** legend text and swatches are editable layout items. After changing the renderer, update the corresponding printed legend swatches and wording too.
- **Reusable styles:** load any `.qml` from the `styles` folder onto the corresponding layer.

`Source_to_reference_crosswalk.csv` records the interpretation for all 623 source polygons. `Reference_legend_colours.csv` records the exact colours and source counts. The GeoPackage stores the original source geometry, classified source geometry, dissolved geometry, contacts, labels, water, boundaries, coordinate grid and optional faults.

## Sources and licences

**Source geology:** Heed725, Tanzania_Geology_Shapefile, commit `2c3db2bff74dbcf0fcedc4685eaacb5d1a910551`.
https://github.com/Heed725/Tanzania_Geology_Shapefile

The repository describes educational/research use and requests attribution to original survey sources. Its original geology licence status remains unchanged. Reference classification fields are separate from the original source fields.

**Reference appearance:** the user's uploaded geotectonic map. Matching unit names are shown in Figure 1, Geological Survey of Tanzania, *A Summary of the Solid Mineral Occurrences and Mineral Potential of Tanzania*.
https://www.gst.go.tz/uploads/documents/sw-1691931166-Newsletter1.pdf

Malagarasi equivalence was also checked against the lithostratigraphic column in *Tanzania Journal of Science* 46(2), 460–474 (2020), which lists the Manyovu, Ilagala, Gagwe, Busondo and Masontwa units of the Malagarasi Supergroup.
https://journals.udsm.ac.tz/index.php/tjs/article/download/8335/6431/20887

**Optional active faults:** GEM Foundation, GEM Global Active Faults Database; East African catalog `Macgregor_AfricaFaults`; master commit `56816508ad92fd6846dad1163b1c8c01376a2cd1`.
https://github.com/GEMScienceTools/gem-global-active-faults

Styron, R. and Pagani, M. (2020), *The GEM Global Active Faults Database*, Earthquake Spectra 36(1_suppl), 160–180. https://doi.org/10.1177/8755293020944182

Fault data are CC BY-SA 4.0. The regional subset was clipped to the map frame and converted to GeoPackage; original catalog identifiers are retained. See `GEM_LICENSE.txt` and https://creativecommons.org/licenses/by-sa/4.0/. Supplied as-is; no endorsement is implied.

**Geographic context:** Natural Earth 1:10 million countries, lakes and rivers; public domain.
https://www.naturalearthdata.com/
https://github.com/nvkelso/natural-earth-vector

New map styling, layout and documented crosswalk are CC BY-SA 4.0. Source datasets retain their separate terms.
